# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: three-products.spec.ts >> M2 native None single: ordinary default crossfade clears raw mirrors, reloads, retries exactly after restart and undoes through Runtime
- Location: tests/e2e/local/three-products.spec.ts:2901:1

# Error details

```
Error: browserType.launch: Executable doesn't exist at /home/runner/.cache/ms-playwright/chromium_headless_shell-1223/chrome-headless-shell-linux64/chrome-headless-shell
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```

# Test source

```ts
  66  |   }
  67  | }
  68  | 
  69  | /** Add bounded connection/page-error observations to the already-installed mounted producer. */
  70  | export function installMountedBootstrapPageDiagnostics(page: Page): () => Promise<void> {
  71  |   const pending = new Set<Promise<void>>();
  72  |   const emit = (detail: MountedBootstrapDiagnosticDetail): Promise<void> | undefined => {
  73  |     try {
  74  |       const operation = page.evaluate((eventDetail) => {
  75  |         try { window.dispatchEvent(new CustomEvent('timeline:save-diagnostic', { detail: { version: 1, ...eventDetail } })); }
  76  |         catch { /* Diagnostic collection is disposable. */ }
  77  |       }, detail).catch(() => {});
  78  |       pending.add(operation);
  79  |       void operation.finally(() => pending.delete(operation));
  80  |       return operation;
  81  |     } catch { /* Diagnostic collection is disposable. */ return undefined; }
  82  |   };
  83  |   const onResponse = (response: Response) => {
  84  |     try {
  85  |       const connectionRoute = mountedBootstrapConnectionRoute(response.url());
  86  |       if (!connectionRoute) return;
  87  |       const status = response.status();
  88  |       const outcome = mountedBootstrapConnectionOutcome(status);
  89  |       return emit({ phase: 'connection-route', connectionRoute, connectionStatus: Number.isInteger(status) ? status : undefined,
  90  |         connectionOutcome: outcome });
  91  |     } catch { /* Diagnostic collection is disposable. */ }
  92  |   };
  93  |   const onRequestFailed = (request: Request) => {
  94  |     try {
  95  |       const connectionRoute = mountedBootstrapConnectionRoute(request.url());
  96  |       if (!connectionRoute) return;
  97  |       return emit({ phase: 'connection-route', connectionRoute, connectionOutcome: 'transport-failure' });
  98  |     } catch { /* Diagnostic collection is disposable. */ }
  99  |   };
  100 |   const onPageError = (error: Error) => {
  101 |     try { return emit({ phase: 'page-error', pageErrorClass: mountedBootstrapPageErrorClass(error), pageErrorCategory: 'runtime' }); }
  102 |     catch { /* Diagnostic collection is disposable. */ }
  103 |   };
  104 |   try {
  105 |     page.on('response', onResponse);
  106 |     page.on('requestfailed', onRequestFailed);
  107 |     page.on('pageerror', onPageError);
  108 |   } catch {
  109 |     try { page.off('response', onResponse); page.off('requestfailed', onRequestFailed); page.off('pageerror', onPageError); } catch { /* Diagnostic cleanup is disposable. */ }
  110 |     return async () => {};
  111 |   }
  112 |   return async () => {
  113 |     try { page.off('response', onResponse); page.off('requestfailed', onRequestFailed); page.off('pageerror', onPageError); }
  114 |     catch { /* Diagnostic cleanup is disposable. */ }
  115 |     await Promise.all([...pending]);
  116 |   };
  117 | }
  118 | 
  119 | /** QUICK shares the F1 browser/runtime boundary, so teardown verifies the Playwright server group is gone. */
  120 | export async function closeQuickBrowser(browser: Browser | undefined, browserServer: Awaited<ReturnType<typeof chromium.launchServer>>): Promise<void> {
  121 |   const child: ChildProcess = browserServer.process();
  122 |   const pid = child.pid;
  123 |   if (!pid) throw new Error('Playwright browser server has no child PID');
  124 |   let cleanupError: unknown;
  125 |   if (browser) try { await browser.close(); } catch (error) { cleanupError = error; }
  126 |   try { await browserServer.close(); } catch (error) { cleanupError ??= error; }
  127 |   if (child.exitCode === null && child.signalCode === null) await new Promise<void>((resolve) => child.once('exit', () => resolve()));
  128 |   if (child.signalCode === 'SIGKILL') cleanupError ??= new Error(`QUICK Chromium process ${pid} exited after SIGKILL`);
  129 |   let groupRemains = false;
  130 |   try { process.kill(-pid, 0); groupRemains = true; } catch { /* browser group exited */ }
  131 |   if (groupRemains) {
  132 |     try { process.kill(-pid, 'SIGKILL'); } catch { /* exited between check and cleanup */ }
  133 |     cleanupError ??= new Error(`QUICK Chromium process group ${pid} remained after browser server close and was force-cleaned`);
  134 |   }
  135 |   if (cleanupError) throw cleanupError;
  136 | }
  137 | 
  138 | function resolveChromium(): string | undefined {
  139 |   if (process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE) return process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE;
  140 |   if (existsSync(chromium.executablePath())) return chromium.executablePath();
  141 |   // The installed Playwright may expect a newer browser build than the one in the image; use what is there.
  142 |   const browsers = process.env.PLAYWRIGHT_BROWSERS_PATH ?? '/opt/pw-browsers';
  143 |   const found = existsSync(browsers) ? readdirSync(browsers).filter((name) => /^chromium-\d+$/.test(name)).sort().pop() : undefined;
  144 |   const candidate = found ? path.join(browsers, found, 'chrome-linux', 'chrome') : undefined;
  145 |   return candidate && existsSync(candidate) ? candidate : undefined;
  146 | }
  147 | 
  148 | export const test = base.extend<object, { harness: DirectHarness; browser: Browser; hungStackLifecycle: undefined }>({
  149 |   // Playwright reads fixture dependencies from the destructuring pattern, so the empty pattern is required.
  150 |   // eslint-disable-next-line no-empty-pattern
  151 |   harness: [async ({}, use) => {
  152 |     const harness = await startDirectHarness();
  153 |     try { await use(harness); } finally { await harness.stop(); }
  154 |   }, { scope: 'worker', timeout: process.env.ASTRID_QUICK_DESCRIPTOR ? 0 : 240_000 }],
  155 |   browser: [async ({ harness }, use) => {
  156 |     if (process.env.ASTRID_QUICK_DESCRIPTOR) {
  157 |       const args = [...harness.chromiumArgs];
  158 |       const downloadsPath = process.env.PLAYWRIGHT_DOWNLOADS_PATH;
  159 |       if (downloadsPath) mkdirSync(downloadsPath, { recursive: true, mode: 0o700 });
  160 |       const installedChrome = process.env.PLAYWRIGHT_USE_INSTALLED_CHROME === '1';
  161 |       const browserServer = await chromium.launchServer({ args, ...(installedChrome ? { channel: 'chrome' as const } : { executablePath: resolveChromium() }), ...(downloadsPath ? { downloadsPath } : {}) });
  162 |       let browser: Browser | undefined;
  163 |       try { browser = await chromium.connect(browserServer.wsEndpoint()); await use(browser); }
  164 |       finally { await closeQuickBrowser(browser, browserServer); }
  165 |     } else {
> 166 |       const browser = await chromium.launch({ args: harness.chromiumArgs, executablePath: resolveChromium() });
      |                                      ^ Error: browserType.launch: Executable doesn't exist at /home/runner/.cache/ms-playwright/chromium_headless_shell-1223/chrome-headless-shell-linux64/chrome-headless-shell
  167 |       try { await use(browser); } finally { await browser.close(); }
  168 |     }
  169 |   }, { scope: 'worker' }],
  170 |   context: async ({ browser, harness }, use) => {
  171 |     const context = await browser.newContext(harness.contextOptions as Parameters<Browser['newContext']>[0]);
  172 |     try { await use(context); } finally { await closeElementApplyDiagnosticContext(context); }
  173 |   },
  174 |   page: elementApplyDiagnosticPageFixture,
  175 |   hungStackLifecycle: [async ({ page, harness }, use) => {
  176 |     const detach = harness.installHungRequestCapture(page);
  177 |     try { await use(undefined); } finally { detach(); }
  178 |   }, { auto: true }],
  179 | });
  180 | 
  181 | export async function currentHead(harness: DirectHarness): Promise<string> {
  182 |   const timelines = await harness.runtimeJson('GET', `/v1/projects/${harness.seed.projectId}/timelines/${harness.seed.timelineId}/composition-revisions?limit=1`);
  183 |   return timelines.body.items.find((item: any) => item.is_current_head).revision_id;
  184 | }
  185 | 
  186 | export async function waitForAudit(harness: DirectHarness, predicate: (entry: ReturnType<DirectHarness['audit']>[number]) => boolean, timeoutMs = 3000) {
  187 |   const deadline = Date.now() + timeoutMs;
  188 |   for (;;) {
  189 |     const hit = harness.audit().filter(predicate);
  190 |     if (hit.length || Date.now() > deadline) return hit;
  191 |     await new Promise((resolve) => setTimeout(resolve, 50));
  192 |   }
  193 | }
  194 | 
  195 | /** Opens the App at the hosted origin with nothing in the URL and returns the requests it made to the door. */
  196 | export async function openApp(page: Page, harness: DirectHarness) {
  197 |   const doorRequests: string[] = [];
  198 |   page.on('request', (request) => { if (request.url().startsWith(`http://127.0.0.1:${DOOR_PORT}/`)) doorRequests.push(`${request.method()} ${request.url()}`); });
  199 |   await page.goto(`${harness.origin}${APP_ENTRY_ROUTE}`);
  200 |   return doorRequests;
  201 | }
  202 | 
  203 | /** Mounts the real editor once so a fresh context can establish its own durable outbox baseline. */
  204 | export async function bootstrapMountedBaseline(context: BrowserContext, harness: DirectHarness): Promise<OutboxRecord[]> {
  205 |   clearMountedBootstrapFailure();
  206 |   let page: Page | undefined;
  207 |   let detachPageDiagnostics: (() => Promise<void>) | undefined;
  208 |   let outcome: 'completed' | 'failed' = 'failed';
  209 |   const run = async <T>(stage: MountedBootstrapStage, operation: () => Promise<T>): Promise<T> => {
  210 |     try {
  211 |       return await operation();
  212 |     } catch (cause) {
  213 |       throw new MountedBootstrapError({ stage, code: 'mounted-bootstrap', class: 'mounted-bootstrap' }, cause);
  214 |     }
  215 |   };
  216 |   try {
  217 |     page = await run('context', () => context.newPage());
  218 |     detachPageDiagnostics = installMountedBootstrapPageDiagnostics(page);
  219 |     await run('navigation', () => openApp(page!, harness).then(() => undefined));
  220 |     await run('connection', () => expectConnected(page!));
  221 |     await run('selection', () => openSeededTimeline(page!, harness));
  222 |     return await run('outbox-read', async () => {
  223 |       let owners: OutboxRecord[] = [];
  224 |       // Track visibility precedes the verified basis/identity reads and durable
  225 |       // session claim. Keep the real editor alive until that claim has persisted.
  226 |       await expect.poll(async () => {
  227 |         const exists = await page!.evaluate(async () => (await indexedDB.databases()).some((db) => db.name === 'astrid.command-outbox'));
  228 |         if (!exists) return false;
  229 |         owners = await commandOutboxes(page!, harness.seed.timelineId);
  230 |         return owners.some((owner) => owner.scope.projectId === harness.seed.projectId && !owner.pending && owner.intents.length === 0);
  231 |       }, { message: 'the bootstrap editor must persist its scoped command owner before closing' }).toBe(true);
  232 |       outcome = 'completed';
  233 |       return owners;
  234 |     });
  235 |   } catch (error) {
  236 |     recordMountedBootstrapFailure(error);
  237 |     throw error;
  238 |   } finally {
  239 |     if (detachPageDiagnostics) {
  240 |       try { await detachPageDiagnostics(); } catch { /* Diagnostic cleanup is disposable. */ }
  241 |     }
  242 |     const testInfo = mountedBootstrapDiagnosticTargets.get(context);
  243 |     if (testInfo) {
  244 |       try { await retainMountedBootstrapDiagnostics(testInfo, page, outcome); } catch { /* Diagnostic retention is disposable. */ }
  245 |     }
  246 |     await page?.close();
  247 |   }
  248 | }
  249 | 
  250 | export const expectConnected = (page: Page) => expect(page.locator(UI.status)).toHaveAttribute('data-state', 'connected');
  251 | 
  252 | /** The editor's first track-name field: the smallest real edit the App offers on the seeded timeline. */
  253 | export const firstTrackName = (page: Page) => page.getByRole('textbox', { name: 'Track name' }).first();
  254 | 
  255 | /** Waits for the editor to show the seeded project's timeline (the editor picks the only project by itself). */
  256 | export async function openSeededTimeline(page: Page, harness: DirectHarness) {
  257 |   await expect(page.getByRole('combobox', { name: 'Select project' })).toContainText(harness.seed.projectName);
  258 |   await expect(page.getByRole('combobox', { name: 'Select timeline' })).toBeVisible();
  259 |   await expect(firstTrackName(page)).toBeVisible();
  260 |   // The editor mounts beneath the connection card and is inert until the card has left: an edit before that is dropped.
  261 |   await expect(page.locator(UI.panel)).toHaveCount(0);
  262 | }
  263 | 
  264 | /** Opens the production embedded canonical ShotEditorView from the parent editor's shot-group label. */
  265 | export async function openEmbeddedCanonicalShot(page: Page, occurrenceId: string, shotName: string) {
  266 |   const label = page.locator('[data-shot-group-key]').filter({ hasText: shotName }).first();
```